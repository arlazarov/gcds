(function animInit() {
  function mount() {
    document.body.classList.add('anim');

    const els = document.querySelectorAll('.reveal, .program');
    if (!els.length) return;

    const io = new IntersectionObserver(
      entries => {
        for (const e of entries) {
          const el = e.target;
          if (e.isIntersecting) {
            el.classList.add('visible');
          } else {
            el.classList.remove('visible');
          }
        }
      },
      { threshold: 0.1, rootMargin: '0px 0px 10% 0px' },
    );

    els.forEach(el => io.observe(el));
  }

  if (document.readyState === 'loading')
    document.addEventListener('DOMContentLoaded', mount);
  else mount();

  const obs = new MutationObserver(mutations => {
    for (const m of mutations) {
      if (m.addedNodes.length > 0) {
        if (document.querySelector('.reveal, .program')) {
          mount();
          break;
        }
      }
    }
  });

  obs.observe(document.body, { childList: true, subtree: true });
})();
